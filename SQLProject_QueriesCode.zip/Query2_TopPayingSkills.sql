WITH Top_paying_Jobs AS(

    SELECT 
        job_id,
        job_title,
        job_schedule_type,
        salary_year_avg,
        name as company_name

    FROM 
    job_postings_fact
    LEFT JOIN company_dim on job_postings_fact.company_id = company_dim.company_id

    WHERE
        (job_location = 'Anywhere' or job_location = 'Lisbon'
        or job_location = 'Lisboa' or job_location = 'Portugal')
        AND salary_year_avg is NOT NULL

    ORDER BY salary_year_avg desc

    limit 10
            )


SELECT 
    Top_paying_Jobs.*,
    skills

from Top_Paying_Jobs
INNER JOIN skills_job_dim ON Top_paying_Jobs.job_id = skills_job_dim.job_id
INNER JOIN skills_dim ON skills_job_dim.skill_id = skills_dim.skill_id

ORDER BY
    salary_year_avg DESC;