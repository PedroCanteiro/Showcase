SELECT 
    job_title,
    job_location,
    job_schedule_type,
    salary_year_avg,
    job_posted_date,
    name as company_name

FROM 
job_postings_fact
LEFT JOIN company_dim on job_postings_fact.company_id = company_dim.company_id

WHERE
    (job_location = 'Anywhere' or  job_location = 'Portugal' or job_location = 'Lisbon' or job_location = 'Lisboa')
    AND salary_year_avg is NOT NULL
   -- removed because all salaries are null or (job_title like '%financ%' or job_title like '%invest%' or job_title like '%portfolio%' or job_title like '%risk%')

ORDER BY salary_year_avg desc

limit 100;
